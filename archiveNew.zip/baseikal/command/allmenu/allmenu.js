const allmenu =  ` 
*list Menu*
┏━━⊱
┣❏listadmin
┣❏listaudio
┣❏listban
┣❏listjualan
┣❏listlogo
┣❏listowner
┣❏listwibu
┣❏listakses
┣❏listaddlist
┣❏listvn
┣❏listpdf
┣❏listzip
┣❏listapk
┣❏listpc
┣❏listgc
┣❏listonline
┣❏listcmd
┗━━⊱
*Menu Owner*
┏━━⊱
┣❏addapk
┣❏delapk
┣❏addzip
┣❏delzip
┣❏addpdf
┣❏delpdf
┣❏addvn
┣❏delvn
┣❏addlist
┣❏dellist
┣❏sendpdf
┣❏sendzip
┣❏sendapk
┗━━⊱
*Only Group*
┏━━⊱
┣❏antilink on / off
┣❏kick 628xxx
┣❏add 628xxx
┣❏promote 628xx
┣❏demote 628xx
┣❏inspect
┣❏sendlinkgc
┣❏linkgroup
┣❏resetlinkgc
┣❏tagall
┣❏hidetag
┣❏group
┣❏setname
┣❏setdesc
┣❏editinfo
┣❏setppgroup
┗━━⊱
*Only Owner*
┏━━⊱
┣❏nowa
┣❏verif
┣❏kenon
┣❏setppbot
┣❏block
┣❏unblock
┣❏setadmin
┣❏updatelist
┣❏setcmd
┣❏delcmd
┗━━⊱
*Random*
┏━━⊱
┣❏fbvideo
┣❏igvideo 
┣❏twitvideo
┣❏textmaker
┣❏tiktokvideo
┣❏tiktokaudio
┣❏play
┣❏mediafire
┣❏toimage
┣❏toonce
┣❏tomp4
┣❏tovn
┣❏togif
┣❏tourl 
┣❏toaud
┣❏sticker
┣❏stickergif
┣❏emojimix
┣❏emojimix2
┣❏smeme
┣❏pinterest
┣❏couple
┣❏coffe
┣❏ktpmaker
┣❏afk
┣❏owner
┣❏getname
┣❏getpic
┣❏infochat
┣❏q
┣❏del
┣❏style
┣❏ss
┣❏penjara
┗━━⊱[ LionGamingOfc ]`
exports.allmenu = allmenu