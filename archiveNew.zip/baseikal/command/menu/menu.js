const menu =  ` 
° Owner  : SultanGz
° Version : 14
° Baileys : 5.0.0

┏━┳┳┳━┳┳┓
┃━┫┃┃┏┫━┫┏┓
┃┏┫┃┃┗┫┃┃┃┃
┗┛┗━┻━┻┻┛┃┃
┏┳┳━┳┳┳┓┏┫┣┳┓
┃┃┃┃┃┃┃┃┣┻┫┃┃
┣┓┃┃┃┃┣┫┃┏┻┻┫
┗━┻━┻━┻
 ▰▱▰▱▰▱▰▱▰▱▰▱▰▱
 *Fitur Lainnya*
┏━━⊱
┣❏ Allmenu
┗━━⊱
*Store - Jualan*
┏━━⊱
┣❏ Jualan
┣❏ Payment
┣❏ Layanan
┗━━⊱
*Tambah Owner*
┏━━⊱
┣❏ Addowner 628xx
┣❏ Delowner 628xxx
┗━━⊱
*Tambah Akses*
┏━━⊱
┣❏ Addakses 628xxxxx
┣❏ Hapusakses 628xxx
┗━━⊱
*Menu Bug*
*EMOJI TERLARANG*
┏━━⊱
┣❏🔧 [ jumlah ]
┣❏🪞 [ jumlah ]
┣❏🛡️ [ jumlah ]
┣❏🗡️ [ jumlah ]
┣❏⚔️ [ jumlah ]
┣❏🦖 [ jumlah ]
┣❏🦕 [ jumlah ]
┣❏👿 [ jumlah ]
┣❏⚡ [ jumlah ]
┣❏😈 [ jumlah ]
┣❏⚔️ [ jumlah ]
┣❏💥 [ jumlah ]
┣❏🍂 [ jumlah ]
┣❏🌪️ [ jumlah ]
┣❏🔥 [ jumlah ]
┣❏🗿 [ jumlah ]
┣❏🐕 [ jumlah ]
┣❏🤣 [ jumlah ]
┣❏😭 [ jumlah ]
┣❏😂 [ jumlah ]
┣❏🥵 [ jumlah ]
┣❏🥶 [ jumlah ]
┣❏😱 [ jumlah ]
┣❏😎 [ jumlah ]
┣❏button [ jumlah ]
┗━━⊱
[ contoh 👿 5 ]
▬▭▬▭▬▭▬▭▬▬▭▬▭▬
*SEND BUG EMOJI*
┏━━⊱
┣❏🌷 628xxx|5
┣❏🐲 628xxx|5
┣❏🐉 628xxx|5
┣❏🌵 628xxx|5
┣❏🎄 628xxx|5
┣❏🌲 628xxx|5
┣❏🌳 628xxx|5
┣❏🌴 628xxx|5
┣❏🌱 628xxx|5
┣❏🌿 628xxx|5
┣❏☘️ 628xxx|5
┣❏🍀 628xxx|5
┗━━⊱
[ contoh 🌷 6281214281312|5 ]
▬▭▬▭▬▭▬▭▬▬▭▬▭▬
*VIRTEXT DELAY*
┏━━⊱
┣❏Virtext [ jumlah ]
┣❏Virtext2 [ jumlah ]
┣❏Virtext3 [ jumlah ]
┣❏Virtext4 [ jumlah ]
┣❏Virtext5 [ jumlah ]
┣❏Virtext6 [ jumlah ]
┣❏Virtext7 [ jumlah ]
┣❏Virtext8 [ jumlah ]
┣❏Virtext9 [ jumlah ]
┣❏Virtext10 [ jumlah ]
┗━━⊱
[ Contoh Virtext1 5 ]
▬▭▬▭▬▭▬▭▬▬▭▬▭▬
*SEND BUG TROLI*
┏━━⊱
┣❏Sendtrol 628xxxx
┣❏Sendtrol2 628xxx
┣❏Sendtrol3 628xxx
┣❏Sendtrol4 628xxx
┣❏Sendtrol5 628xxx
┗━━⊱
[ contoh Sendtrol 6281214281312 ]
▬▭▬▭▬▭▬▭▬▬▭▬▭▬
*SEND BUG SANTET*
┏━━⊱
┣❏Santet 628xxxx
┣❏Santet2 628xxx
┣❏Santet3 628xxx
┣❏Santet4 628xxx
┣❏Santet5 628xxx
┗━━⊱
[ contoh Santet 6281214281312 ]
▬▭▬▭▬▭▬▭▬▬▭▬▭▬
*SEND BUG DOKUMEN*
┏━━⊱
┣❏Senddocu 628xxxx
┣❏Senddocu2 628xxx
┣❏Senddocu3 628xxx
┣❏Senddocu4 628xxx
┣❏Senddocu5 628xxx
┗━━⊱
[ contoh Senddocu 6281214281312 ]
▬▭▬▭▬▭▬▭▬▬▭▬▭▬
*SEND BUG LOKASI*
┏━━⊱
┣❏Sendlokas 628xxxx
┣❏Sendlokas2 628xxx
┣❏Sendlokas3 628xxx
┣❏Sendlokas4 628xxx
┣❏Sendlokas5 628xxx
┗━━⊱
[ contoh Sendlokas 6281214281312 ]
▬▭▬▭▬▭▬▭▬▬▭▬▭▬
*SEND BUG INVITE*
┏━━⊱
┣❏Sendinvite 628xxxx
┣❏Sendinvite2 628xxx
┣❏Sendinvite3 628xxx
┣❏Sendinvite4 628xxx
┣❏Sendinvite5 628xxx
┗━━⊱
[ contoh Sendinvite 6281214281312 ]
▬▭▬▭▬▭▬▭▬▬▭▬▭▬
*SEND BUG LIST*
┏━━⊱
┣❏Sendbuglist 628xxxx
┣❏Sendbuglist2 628xxx
┣❏Sendbuglist3 628xxx
┣❏Sendbuglist4 628xxx
┣❏Sendbuglist5 628xxx
┗━━⊱
[ contoh Sendbuglist 6281214281312 ]
▬▭▬▭▬▭▬▭▬▬▭▬▭▬
*SEND VIRUS IP / ANDRO*
┏━━⊱
┣❏Sendvirus 628xxxx
┣❏Sendvirus2 628xxx
┣❏Sendvirus3 628xxx
┣❏Sendvirus4 628xxx
┣❏Sendvirus5 628xxx
┣❏Sendvirus6 628xxx
┣❏Sendvirus7 628xxx
┣❏Sendvirus8 628xxx
┣❏Sendvirus9 628xxx
┣❏Sendvirus10 628xx
┗━━⊱
[ contoh Sendvirus 6281214281312 ]
▬▭▬▭▬▭▬▭▬▬▭▬▭▬
*JADI BUG*
┏━━⊱
┣❏Jadikatalog [reply sticker]
┣❏Jadijago [ Text nya ]
┣❏Jadipolling [ Text nya ]
┣❏Jaditroli [ Text nya ]
┣❏Jadilokas [ Text nya ]
┣❏Jadidarknes [ Text nya ]
┣❏Jadidocu [ Text nya ]
┣❏Jadibuginvite [ Text nya ]
┣❏Jadibugpayment [ Text nya ]
┣❏Jadibugsw [ Text nya ]
┣❏Jadibugbutton [ Text nya ]
┣❏Jadivirtext1 [ Text nya ]
┣❏Jadivirtext2 [ Text nya ]
┣❏Jadivirtext3 [ Text nya ]
┣❏Jadivirtext4 [ Text nya ]
┣❏Jadivirtext5 [ Text nya ]
┣❏Jadivirtext6 [ Text nya ]
┣❏Jadivirtext7 [ Text nya ]
┣❏Jadivirtext8 [ Text nya ]
┣❏Jadivirtext9 [ Text nya ]
┣❏Jadivirtext10 [ Text nya ]
┣❏buggamvn
┣❏buggastick
┗━━⊱
[ Contoh Jadijago Haikal ]
 ▰▱▰▱▰▱▰▱▰▱▰▱▰▱`
exports.menu = menu